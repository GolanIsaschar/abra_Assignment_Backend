<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Laravel\Prompts\Table;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::dropIfExists('messages');

        Schema::create("messages", function (Blueprint $table) {
            $table->id('messageId');
            $table->tinyInteger('userSenderId');
            $table->tinyInteger('userRecivierId');
            $table->text('messageContent');
            $table->text('messageSubject');
            $table->tinyInteger('isRead');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        //
    }
};
